library(dplyr)
library(tibble)
source("R/missing_data_functions.R")

n_reps <- 200
mechanisms <- c("mcar", "mar_covariate", "mar_outcome", "mnar")

cat("=== 1. Main experiment: 4 mechanisms x 6 methods x", n_reps, "replications (n = 500, 30% of x2 missing) ===\n")
set.seed(2026)
main <- bind_rows(lapply(mechanisms, function(mech) {
  bind_rows(lapply(seq_len(n_reps), function(i) run_replication(mech) |> mutate(rep = i))) |>
    mutate(mechanism = mech)
}))
main_summary <- bind_rows(lapply(mechanisms, function(mech) {
  summarise_replications(filter(main, mechanism == mech)) |> mutate(mechanism = mech)
}))
print(main_summary |> filter(term == "x2") |> mutate(across(where(is.numeric), ~ round(.x, 3))), n = 30)

cat("\n=== 2. How bad does complete-case get as more data goes missing? (MAR on the outcome) ===\n")
set.seed(7)
rates <- c(0.1, 0.3, 0.5, 0.7)
rate_scan <- bind_rows(lapply(rates, function(rt) {
  res <- bind_rows(lapply(1:100, function(i) run_replication("mar_outcome", target = rt,
                                                             methods = c("Complete-case", "Multiple imputation"))))
  summarise_replications(res) |> mutate(missing_rate = rt)
}))
print(rate_scan |> filter(term == "x2") |> select(method, missing_rate, bias, coverage) |> mutate(across(where(is.numeric), ~ round(.x, 3))))

cat("\n=== 2b. How strongly must missingness depend on x2 itself (MNAR) before multiple imputation breaks? ===\n")
set.seed(9)
strengths <- c(0, 1.5, 3, 5)
strength_scan <- bind_rows(lapply(strengths, function(st) {
  res <- bind_rows(lapply(1:100, function(i) {
    d_full <- simulate_data(500)
    d_miss <- impose_missing(d_full, "mnar", strength = st)
    bind_rows(lapply(c("Complete-case", "Multiple imputation"), function(nm) {
      r <- ALL_METHODS[[nm]](d_full, d_miss)
      tibble(method = nm, term = c("x1", "x2"), estimate = unname(r$est), se = unname(r$se), df = r$df)
    }))
  }))
  summarise_replications(res) |> mutate(strength = st)
}))
print(strength_scan |> filter(term == "x2") |> select(method, strength, bias, coverage) |> mutate(across(where(is.numeric), ~ round(.x, 3))))

cat("\n=== 3. One illustrative dataset (MAR on the outcome) for the plots ===\n")
set.seed(11)
d_full <- simulate_data(500)
d_miss <- impose_missing(d_full, "mar_outcome")
miss <- is.na(d_miss$x2)
mean_imp <- d_miss; mean_imp$x2[miss] <- mean(d_miss$x2, na.rm = TRUE)
reg_fit <- lm(x2 ~ x1 + y, data = d_miss[!miss, ])
reg_imp <- d_miss; reg_imp$x2[miss] <- predict(reg_fit, newdata = d_miss[miss, ])
mi_imp <- impute_x2_once(d_miss)
illustration <- bind_rows(
  mutate(mean_imp, method = "Mean imputation", imputed = miss),
  mutate(reg_imp,  method = "Regression imputation", imputed = miss),
  mutate(mi_imp,   method = "One multiple-imputation draw", imputed = miss))
cat("Share missing:", round(mean(miss), 3), "\n")

saveRDS(list(main_summary = main_summary, rate_scan = rate_scan, strength_scan = strength_scan, illustration = illustration,
             n_reps = n_reps, true_beta = TRUE_BETA),
        "data/clean/simulation_results.rds")
