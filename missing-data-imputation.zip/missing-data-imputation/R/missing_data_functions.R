# Missing-data handling, graded against a KNOWN truth. Every dataset is
# simulated from y = 2 + 1.5 x1 + 1.0 x2 + e, then values of x2 are
# deleted by one of four mechanisms. Each method tries to recover the
# true coefficients (1.5 and 1.0), over many replications, so bias and
# confidence-interval coverage can be measured rather than eyeballed.
library(dplyr)
library(tibble)

TRUE_BETA <- c(x1 = 1.5, x2 = 1.0)

#' Complete data: x2 correlated with x1 (r = 0.5, unit variances).
simulate_data <- function(n = 500) {
  x1 <- rnorm(n)
  x2 <- 0.5 * x1 + rnorm(n, sd = sqrt(1 - 0.25))
  y  <- 2 + 1.5 * x1 + 1.0 * x2 + rnorm(n)
  data.frame(x1 = x1, x2 = x2, y = y)
}

#' Intercept a such that mean(plogis(a + score)) = target, so every
#' mechanism deletes about the same share (default 30%) of x2 and the
#' mechanisms differ only in WHAT the missingness depends on.
calibrate_intercept <- function(score, target = 0.3) {
  uniroot(function(a) mean(plogis(a + score)) - target, c(-30, 30))$root
}

#' Delete x2 values by mechanism:
#'   mcar          constant probability: unrelated to anything
#'   mar_covariate depends on x1 (always observed)
#'   mar_outcome   depends on y (always observed)
#'   mnar          depends on x2 ITSELF, the value being deleted
#' MCAR/MAR/MNAR = missing completely at random / at random / not at
#' random (Rubin, 1976). MAR means missingness depends only on OBSERVED
#' data; MNAR means it depends on the unobserved value itself.
impose_missing <- function(df, mechanism = c("mcar", "mar_covariate", "mar_outcome", "mnar"),
                           target = 0.3, strength = 1.5) {
  mechanism <- match.arg(mechanism)
  score <- switch(mechanism,
    mcar          = rep(0, nrow(df)),
    mar_covariate = strength * as.numeric(scale(df$x1)),
    mar_outcome   = strength * as.numeric(scale(df$y)),
    mnar          = strength * as.numeric(scale(df$x2)))
  p <- plogis(calibrate_intercept(score, target) + score)
  miss <- rbinom(nrow(df), 1, p) == 1
  out <- df
  out$x2[miss] <- NA
  out
}

# ---- one function per method; each returns list(est, se, df) -----------

summarise_fit <- function(fit) {
  co <- summary(fit)$coefficients
  list(est = c(x1 = co["x1", 1], x2 = co["x2", 1]),
       se  = c(x1 = co["x1", 2], x2 = co["x2", 2]),
       df  = fit$df.residual)
}

method_full <- function(d_full, d_miss) summarise_fit(lm(y ~ x1 + x2, data = d_full))   # oracle: no deletion

method_complete_case <- function(d_full, d_miss) summarise_fit(lm(y ~ x1 + x2, data = d_miss, na.action = na.omit))

#' Replace each missing x2 with the observed mean of x2.
method_mean <- function(d_full, d_miss) {
  d <- d_miss
  d$x2[is.na(d$x2)] <- mean(d$x2, na.rm = TRUE)
  summarise_fit(lm(y ~ x1 + x2, data = d))
}

#' Replace each missing x2 with its regression prediction from (x1, y).
#' Deterministic: every imputed point lies exactly on the fitted line.
method_regression <- function(d_full, d_miss) {
  d <- d_miss
  obs <- !is.na(d$x2)
  fit <- lm(x2 ~ x1 + y, data = d[obs, ])
  d$x2[!obs] <- predict(fit, newdata = d[!obs, ])
  summarise_fit(lm(y ~ x1 + x2, data = d))
}

#' ONE proper stochastic draw of the missing x2. "Proper" means the
#' imputation model's own parameters are drawn from their posterior (not
#' just plugged in at the point estimate), so the imputations carry the
#' extra uncertainty from having estimated that model from limited data.
#' Posterior (flat prior): sigma2 = RSS / chi-square(df),
#' beta | sigma2 ~ Normal(beta_hat, sigma2 (X'X)^-1).
impute_x2_once <- function(d, use_y = TRUE) {
  rhs <- if (use_y) c("x1", "y") else "x1"
  obs <- !is.na(d$x2)
  X <- cbind(1, as.matrix(d[, rhs, drop = FALSE]))
  Xo <- X[obs, , drop = FALSE]
  yo <- d$x2[obs]
  XtX_inv <- solve(crossprod(Xo))
  beta_hat <- XtX_inv %*% crossprod(Xo, yo)
  rss <- sum((yo - Xo %*% beta_hat)^2)
  sigma2 <- rss / rchisq(1, length(yo) - ncol(Xo))
  beta_star <- beta_hat + sqrt(sigma2) * t(chol(XtX_inv)) %*% rnorm(ncol(Xo))
  d$x2[!obs] <- as.vector(X[!obs, , drop = FALSE] %*% beta_star) + rnorm(sum(!obs), 0, sqrt(sigma2))
  d
}

#' Rubin's rules for pooling M completed-data estimates of one quantity.
#'   Qbar = mean of estimates       (the pooled estimate)
#'   Ubar = mean of squared SEs     (within-imputation variance)
#'   B    = variance of estimates   (between-imputation variance)
#'   T    = Ubar + (1 + 1/M) B      (total variance)
#' df follows Rubin (1987): (M - 1) (1 + 1/r)^2 with r = (1 + 1/M) B / Ubar.
rubin_pool <- function(est, var_within) {
  M <- length(est)
  qbar <- mean(est); ubar <- mean(var_within); b <- var(est)
  total <- ubar + (1 + 1 / M) * b
  r <- (1 + 1 / M) * b / ubar
  list(estimate = qbar, se = sqrt(total), df = if (r > 0) (M - 1) * (1 + 1 / r)^2 else Inf)
}

#' Multiple imputation: M stochastic completions, a regression on each,
#' pooled by Rubin's rules. use_y = FALSE deliberately OMITS the outcome
#' from the imputation model, a classic mistake.
method_mi <- function(d_full, d_miss, M = 20, use_y = TRUE) {
  fits <- lapply(seq_len(M), function(m) summarise_fit(lm(y ~ x1 + x2, data = impute_x2_once(d_miss, use_y))))
  pooled <- lapply(c("x1", "x2"), function(term) {
    rubin_pool(vapply(fits, function(f) f$est[[term]], numeric(1)),
               vapply(fits, function(f) f$se[[term]]^2, numeric(1)))
  })
  list(est = c(x1 = pooled[[1]]$estimate, x2 = pooled[[2]]$estimate),
       se  = c(x1 = pooled[[1]]$se, x2 = pooled[[2]]$se),
       df  = min(pooled[[1]]$df, pooled[[2]]$df))
}

method_mi_no_y <- function(d_full, d_miss, M = 20) method_mi(d_full, d_miss, M = M, use_y = FALSE)

ALL_METHODS <- list(
  `Full data (oracle)` = method_full,
  `Complete-case`      = method_complete_case,
  `Mean imputation`    = method_mean,
  `Regression imputation` = method_regression,
  `Multiple imputation`   = method_mi,
  `MI without y (mistake)` = method_mi_no_y
)

#' One replication: simulate, delete, run every requested method.
run_replication <- function(mechanism, n = 500, target = 0.3, methods = names(ALL_METHODS)) {
  d_full <- simulate_data(n)
  d_miss <- impose_missing(d_full, mechanism, target)
  bind_rows(lapply(methods, function(nm) {
    r <- ALL_METHODS[[nm]](d_full, d_miss)
    tibble(method = nm, term = c("x1", "x2"), estimate = unname(r$est), se = unname(r$se), df = r$df)
  }))
}

#' Bias, spread, RMSE and 95% CI coverage over replications, per
#' method and term. se_ratio = mean reported SE / actual SD of the
#' estimates: below 1 means the method is overconfident.
summarise_replications <- function(results) {
  results |>
    mutate(truth = TRUE_BETA[term],
           covered = abs(estimate - truth) <= qt(0.975, df) * se) |>
    group_by(method, term) |>
    summarise(bias = mean(estimate - truth), empirical_sd = sd(estimate),
              rmse = sqrt(mean((estimate - truth)^2)),
              coverage = mean(covered), se_ratio = mean(se) / sd(estimate), .groups = "drop")
}
