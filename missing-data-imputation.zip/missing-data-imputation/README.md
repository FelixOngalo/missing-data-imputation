# Missing Data: Why the Method Matters

**Question:** *(fill in)* When part of a predictor is missing, which handling method recovers the truth, and when does "just drop incomplete rows" mislead?

**Key findings:** *(fill in after running: bias and coverage by mechanism and method; the one scenario where multiple imputation struggles)*

**Tools:** R (base plus dplyr/tibble), from-scratch multiple imputation and Rubin's rules, Monte Carlo simulation, Quarto report with short proofs

## Reproduce

1. `install.packages("tidyverse")`
2. Run `R/01_run_simulation.R` (a few minutes: 5 scenarios of 100-200 replications each)
3. Render `reports/report.qmd`

## Design

Simulated truth: y = 2 + 1.5 x1 + 1.0 x2 + noise, with x2 correlated with x1. Thirty percent of x2 is deleted by four mechanisms (MCAR, MAR on x1, MAR on y, MNAR on x2). Six methods are graded on bias, spread, RMSE and 95% CI coverage over repeated datasets:

| Method | Idea |
|---|---|
| Full data (oracle) | No deletion; the best any method could do |
| Complete-case | Drop incomplete rows |
| Mean imputation | Fill with the observed mean |
| Regression imputation | Fill with the regression prediction (no noise) |
| Multiple imputation | 20 stochastic proper imputations pooled by Rubin's rules |
| MI without y | The same, but omitting the outcome from the imputation model (a classic mistake) |

## Key concepts

| Concept | Meaning |
|---|---|
| MCAR / MAR / MNAR | Missingness unrelated to data / related to observed data only / related to the missing value itself |
| Coverage | How often a 95% interval contains the truth; the honest test of uncertainty claims |
| Rubin's rules | Pool M analyses: total variance = within + (1 + 1/M) x between |
| Proper imputation | Draw imputation-model parameters from their posterior, not just plug in estimates |

## Project structure

```
R/missing_data_functions.R   simulation, deletion mechanisms, six methods, Rubin pooling, summaries
R/01_run_simulation.R        main experiment, two stress tests, illustrative dataset
reports/report.qmd           taxonomy, three short proofs, results, interpretation
```

## Limitations

- Only one predictor is ever missing, with a correctly specified linear-Gaussian imputation model.
- MAR vs. MNAR cannot be tested from observed data; use sensitivity analysis in practice.
- Teaching implementation; use `mice` for real work.
- *(add your own)*
